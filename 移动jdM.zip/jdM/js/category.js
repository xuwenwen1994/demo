window.onload = function (ev) {
    /*左侧的区域滚动*/
    new IScroll('aside');
    /*右侧的区域滚动*/
    new IScroll('article');
};